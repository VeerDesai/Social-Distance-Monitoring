Project Title:

Formal Modelling of Social Distance Monitoring System Using UPPAAL Model Checker

After the rise of the COVID-19 pandemic since late December 2019, Social distancing is very important to prevent the contagious
virus transmission.So we have built a social distance monitoring system using YOLOv5 algorithm.
As our title suggests,we have done the formal modelling of the system using UPPAAL model checker 
in which we have verified 11 queries whether the satisfy or not.

Download YOLOv5 weigths from google and then put them into weights folder

Team Members:
Ekansh Gaikwad 191IT217    
Niranjan Hegde 191IT235   
Veerkumar Desai 191IT256
Rahul Nayaka 191IT243 

Contents:
Code folder:
This folder contains all the code(python),data and model checking subfolder.Model checking subfolder contains methodology,state diagram,
queries and model checking images.
## Model training is done using YOLOv5 weights which are pretrained on COCO dataset

Final report:It contains IEEE format report generated in overleaf. Overall it is a brief explanation of the project developed by us including methodology ,objectives and formal verification part.We have shown the result and analysis of the project.		

Final presentation : This contains the Presentation that we have delivered.

Tools used:
Overleaf, for Latex Report genration
UPPAAL, formal modelling.

Run the model on a single video input
##
$ python detect.py --source ./inference/videos/input.mp4
##

## Results are stored in inference/output folder 




